# Eventa - Event & Workshop Registration (React + FastAPI + MySQL)

## 1. Database
```bash
mysql -u root -p < backend/schema.sql
```

## 2. Backend
```bash
cd backend
python -m venv venv && source venv/bin/activate     # Windows: venv\Scripts\activate
pip install -r requirements.txt
export DATABASE_URL="mysql+pymysql://root:YOUR_PASSWORD@localhost:3306/eventa"   # Windows: set ...
export SECRET_KEY="a-long-random-string"
uvicorn main:app --reload --port 8000
```
Docs: http://localhost:8000/docs. A default admin is created on first start:
`admin@eventa.com` / `admin123` (change via ADMIN_EMAIL / ADMIN_PASSWORD).

## 3. Frontend
```bash
cd frontend
npm install
npm run dev        # http://localhost:5173
```

## How capacity works
`events.seats_taken` is updated in the same transaction as the registration insert, after locking the
event row (`SELECT ... FOR UPDATE`). A full event returns 409, a student can't register twice
(UNIQUE user+event), cancelling frees a seat, and admins can't lower capacity below seats already booked.
The UI shows the new count immediately from the API response.

## Roles
- Student: sign up, browse, register/cancel, "My registrations".
- Admin: create/edit/delete events, view attendees.

## Run everything with Docker (one command)
```bash
docker compose up --build
```
- App: http://localhost:5173
- API docs: http://localhost:8000/docs
- Admin login: `admin@eventa.com` / `admin123`

Each `Dockerfile` must contain only Docker instructions (`FROM`, `RUN`, `COPY`...). If Docker says
"unknown instruction: const", a JavaScript file was saved as a Dockerfile.
Before deploying, change `SECRET_KEY`, `ADMIN_PASSWORD` and the MySQL root password in `docker-compose.yml`.

## Sample data, tests & reports
```bash
cd backend
python seed.py                           # adds 6 sample events (run once)
pip install -r requirements-dev.txt && pytest -q    # capacity, auth and role tests
mysql -u root -p < queries.sql           # views + report queries for your DBMS report
```
In Docker: `docker compose exec backend python seed.py`.

## Project layout
```
backend/   main.py  seed.py  schema.sql  queries.sql  tests/  Dockerfile
frontend/  src/ (pages, Sidebar, EventCard, auth, api)  Dockerfile  nginx.conf
docs/      ER_DIAGRAM.md (ER diagram + API table)
.github/   workflows/ci.yml (tests + build on every push)
docker-compose.yml  LICENSE  .gitignore
```

## Deploy on Render
This repo has **no Node server** (`index.js`). Backend = Python (FastAPI), frontend = static Vite build.
Render's default Node settings will fail with `Cannot find module .../index.js`.

1. Create a MySQL database (Render has no managed MySQL): Aiven, TiDB Cloud, Railway, or Clever Cloud.
   Copy it as `mysql+pymysql://USER:PASS@HOST:PORT/DBNAME`. The API creates the tables itself on first start.
2. Push the repo to GitHub, then Render > New > **Blueprint** > select the repo (uses `render.yaml`).
3. Fill the prompted variables: `DATABASE_URL`, `ADMIN_PASSWORD`, then after the first deploy set
   `CORS_ORIGINS` (frontend URL) and `VITE_API_URL` (API URL), and redeploy the frontend.
   Set `DB_SSL=true` if your MySQL provider requires TLS.
