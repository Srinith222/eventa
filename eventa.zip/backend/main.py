"""Eventa API - FastAPI + MySQL. Run: uvicorn main:app --reload"""
import os
from datetime import datetime, timedelta
from typing import Optional

import bcrypt
from fastapi import FastAPI, Depends, HTTPException
from fastapi.middleware.cors import CORSMiddleware
from fastapi.security import OAuth2PasswordBearer, OAuth2PasswordRequestForm
from jose import jwt, JWTError
from pydantic import BaseModel, Field
from sqlalchemy import (create_engine, Column, Integer, String, Text, DateTime,
                        ForeignKey, UniqueConstraint, func)
from sqlalchemy.exc import IntegrityError
from sqlalchemy.orm import sessionmaker, declarative_base, Session

DATABASE_URL = os.getenv("DATABASE_URL", "mysql+pymysql://root:password@localhost:3306/eventa")
SECRET_KEY = os.getenv("SECRET_KEY", "change-me-in-production")
ALGO, TOKEN_HOURS = "HS256", 12
ADMIN_EMAIL = os.getenv("ADMIN_EMAIL", "admin@eventa.com")
ADMIN_PASSWORD = os.getenv("ADMIN_PASSWORD", "admin123")

_args = {"ssl": {"fake_flag_to_enable_tls": True}} if os.getenv("DB_SSL", "").lower() == "true" else {}
engine = create_engine(DATABASE_URL, pool_pre_ping=True, connect_args=_args)
SessionLocal = sessionmaker(bind=engine, autoflush=False)
Base = declarative_base()


class User(Base):
    __tablename__ = "users"
    id = Column(Integer, primary_key=True)
    name = Column(String(100), nullable=False)
    email = Column(String(150), unique=True, nullable=False)
    password_hash = Column(String(255), nullable=False)
    role = Column(String(20), nullable=False, default="student")
    created_at = Column(DateTime, server_default=func.now())


class Event(Base):
    __tablename__ = "events"
    id = Column(Integer, primary_key=True)
    title = Column(String(200), nullable=False)
    description = Column(Text)
    category = Column(String(20), nullable=False, default="Event")
    venue = Column(String(200), nullable=False)
    starts_at = Column(DateTime, nullable=False)
    capacity = Column(Integer, nullable=False)
    seats_taken = Column(Integer, nullable=False, default=0)
    created_at = Column(DateTime, server_default=func.now())


class Registration(Base):
    __tablename__ = "registrations"
    id = Column(Integer, primary_key=True)
    user_id = Column(Integer, ForeignKey("users.id", ondelete="CASCADE"), nullable=False)
    event_id = Column(Integer, ForeignKey("events.id", ondelete="CASCADE"), nullable=False)
    created_at = Column(DateTime, server_default=func.now())
    __table_args__ = (UniqueConstraint("user_id", "event_id", name="uq_user_event"),)


Base.metadata.create_all(engine)

# ---------- schemas ----------
class RegisterIn(BaseModel):
    name: str = Field(min_length=2, max_length=100)
    email: str = Field(pattern=r"^[^@\s]+@[^@\s]+\.[^@\s]+$")
    password: str = Field(min_length=6, max_length=72)


class EventIn(BaseModel):
    title: str = Field(min_length=2)
    description: str = ""
    category: str = Field(pattern="^(Event|Workshop)$")
    venue: str
    starts_at: datetime
    capacity: int = Field(gt=0)


# ---------- helpers ----------
def get_db():
    db = SessionLocal()
    try:
        yield db
    finally:
        db.close()


oauth2 = OAuth2PasswordBearer(tokenUrl="/auth/login")
oauth2_optional = OAuth2PasswordBearer(tokenUrl="/auth/login", auto_error=False)


def hash_pw(p: str) -> str:
    return bcrypt.hashpw(p.encode()[:72], bcrypt.gensalt()).decode()


def check_pw(p: str, h: str) -> bool:
    return bcrypt.checkpw(p.encode()[:72], h.encode())


def make_token(user: User) -> str:
    exp = datetime.utcnow() + timedelta(hours=TOKEN_HOURS)
    return jwt.encode({"sub": str(user.id), "exp": exp}, SECRET_KEY, algorithm=ALGO)


def user_from_token(token: Optional[str], db: Session) -> Optional[User]:
    if not token:
        return None
    try:
        uid = int(jwt.decode(token, SECRET_KEY, algorithms=[ALGO])["sub"])
    except (JWTError, ValueError, KeyError):
        return None
    return db.get(User, uid)


def current_user(token: str = Depends(oauth2), db: Session = Depends(get_db)) -> User:
    user = user_from_token(token, db)
    if not user:
        raise HTTPException(401, "Invalid or expired token")
    return user


def optional_user(token: Optional[str] = Depends(oauth2_optional), db: Session = Depends(get_db)):
    return user_from_token(token, db)


def admin_only(user: User = Depends(current_user)) -> User:
    if user.role != "admin":
        raise HTTPException(403, "Admin access required")
    return user


def user_out(u: User):
    return {"id": u.id, "name": u.name, "email": u.email, "role": u.role}


def event_out(e: Event, registered_ids: set):
    return {
        "id": e.id, "title": e.title, "description": e.description, "category": e.category,
        "venue": e.venue, "starts_at": e.starts_at.isoformat(), "capacity": e.capacity,
        "seats_taken": e.seats_taken, "seats_left": e.capacity - e.seats_taken,
        "is_full": e.seats_taken >= e.capacity, "is_registered": e.id in registered_ids,
    }


def my_event_ids(db: Session, user: Optional[User]) -> set:
    if not user:
        return set()
    return {r.event_id for r in db.query(Registration.event_id).filter_by(user_id=user.id)}


# ---------- app ----------
app = FastAPI(title="Eventa API")
app.add_middleware(CORSMiddleware, allow_origins=os.getenv("CORS_ORIGINS", "http://localhost:5173").split(","),
                   allow_credentials=True, allow_methods=["*"], allow_headers=["*"])


@app.on_event("startup")
def seed_admin():
    with SessionLocal() as db:
        if not db.query(User).filter_by(email=ADMIN_EMAIL).first():
            db.add(User(name="Admin", email=ADMIN_EMAIL, password_hash=hash_pw(ADMIN_PASSWORD), role="admin"))
            db.commit()


# ---------- auth ----------
@app.post("/auth/register", status_code=201)
def register(data: RegisterIn, db: Session = Depends(get_db)):
    email = data.email.lower()
    if db.query(User).filter_by(email=email).first():
        raise HTTPException(409, "Email already registered")
    user = User(name=data.name.strip(), email=email, password_hash=hash_pw(data.password), role="student")
    db.add(user)
    db.commit()
    return {"access_token": make_token(user), "token_type": "bearer", "user": user_out(user)}


@app.post("/auth/login")
def login(form: OAuth2PasswordRequestForm = Depends(), db: Session = Depends(get_db)):
    user = db.query(User).filter_by(email=form.username.lower()).first()
    if not user or not check_pw(form.password, user.password_hash):
        raise HTTPException(401, "Incorrect email or password")
    return {"access_token": make_token(user), "token_type": "bearer", "user": user_out(user)}


@app.get("/auth/me")
def me(user: User = Depends(current_user)):
    return user_out(user)


# ---------- events ----------
@app.get("/events")
def list_events(db: Session = Depends(get_db), user: Optional[User] = Depends(optional_user)):
    ids = my_event_ids(db, user)
    return [event_out(e, ids) for e in db.query(Event).order_by(Event.starts_at)]


@app.get("/events/{event_id}")
def get_event(event_id: int, db: Session = Depends(get_db), user: Optional[User] = Depends(optional_user)):
    e = db.get(Event, event_id)
    if not e:
        raise HTTPException(404, "Event not found")
    return event_out(e, my_event_ids(db, user))


@app.post("/events", status_code=201)
def create_event(data: EventIn, db: Session = Depends(get_db), _: User = Depends(admin_only)):
    e = Event(**data.model_dump(), seats_taken=0)
    db.add(e)
    db.commit()
    return event_out(e, set())


@app.put("/events/{event_id}")
def update_event(event_id: int, data: EventIn, db: Session = Depends(get_db), _: User = Depends(admin_only)):
    e = db.query(Event).filter_by(id=event_id).with_for_update().first()
    if not e:
        raise HTTPException(404, "Event not found")
    if data.capacity < e.seats_taken:
        raise HTTPException(400, f"Capacity cannot be lower than the {e.seats_taken} seats already booked")
    for k, v in data.model_dump().items():
        setattr(e, k, v)
    db.commit()
    return event_out(e, set())


@app.delete("/events/{event_id}", status_code=204)
def delete_event(event_id: int, db: Session = Depends(get_db), _: User = Depends(admin_only)):
    e = db.get(Event, event_id)
    if not e:
        raise HTTPException(404, "Event not found")
    db.delete(e)
    db.commit()


# ---------- registrations (capacity-safe) ----------
@app.post("/events/{event_id}/register")
def register_for_event(event_id: int, db: Session = Depends(get_db), user: User = Depends(current_user)):
    # Row lock: two students clicking the last seat at once cannot both succeed.
    e = db.query(Event).filter_by(id=event_id).with_for_update().first()
    if not e:
        raise HTTPException(404, "Event not found")
    if db.query(Registration).filter_by(user_id=user.id, event_id=event_id).first():
        raise HTTPException(409, "You are already registered for this event")
    if e.seats_taken >= e.capacity:
        raise HTTPException(409, "This event is full")
    db.add(Registration(user_id=user.id, event_id=event_id))
    e.seats_taken += 1
    try:
        db.commit()
    except IntegrityError:
        db.rollback()
        raise HTTPException(409, "You are already registered for this event")
    return event_out(e, {e.id})


@app.delete("/events/{event_id}/register")
def cancel_registration(event_id: int, db: Session = Depends(get_db), user: User = Depends(current_user)):
    e = db.query(Event).filter_by(id=event_id).with_for_update().first()
    if not e:
        raise HTTPException(404, "Event not found")
    reg = db.query(Registration).filter_by(user_id=user.id, event_id=event_id).first()
    if not reg:
        raise HTTPException(404, "You are not registered for this event")
    db.delete(reg)
    e.seats_taken = max(0, e.seats_taken - 1)
    db.commit()
    return event_out(e, set())


@app.get("/me/registrations")
def my_registrations(db: Session = Depends(get_db), user: User = Depends(current_user)):
    rows = (db.query(Event).join(Registration, Registration.event_id == Event.id)
            .filter(Registration.user_id == user.id).order_by(Event.starts_at).all())
    return [event_out(e, {e.id}) for e in rows]


@app.get("/events/{event_id}/attendees")
def attendees(event_id: int, db: Session = Depends(get_db), _: User = Depends(admin_only)):
    rows = (db.query(User, Registration.created_at).join(Registration, Registration.user_id == User.id)
            .filter(Registration.event_id == event_id).order_by(Registration.created_at).all())
    return [{**user_out(u), "registered_at": ts.isoformat() if ts else None} for u, ts in rows]
