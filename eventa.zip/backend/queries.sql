-- Reporting queries & views for the DBMS project report. Run after schema.sql.
USE eventa;

-- 1. Live availability per event
CREATE OR REPLACE VIEW event_availability AS
SELECT id, title, category, starts_at, capacity, seats_taken,
       capacity - seats_taken AS seats_left,
       ROUND(seats_taken / capacity * 100, 1) AS fill_percent
FROM events;

-- 2. Most popular events
SELECT title, seats_taken, capacity FROM events ORDER BY seats_taken DESC LIMIT 5;

-- 3. Attendee list for one event (change the id)
SELECT u.name, u.email, r.created_at AS registered_at
FROM registrations r JOIN users u ON u.id = r.user_id
WHERE r.event_id = 1 ORDER BY r.created_at;

-- 4. Events a given student registered for
SELECT e.title, e.starts_at, e.venue
FROM registrations r JOIN events e ON e.id = r.event_id
WHERE r.user_id = 2 ORDER BY e.starts_at;

-- 5. Students with the most registrations
SELECT u.name, COUNT(*) AS total
FROM registrations r JOIN users u ON u.id = r.user_id
GROUP BY u.id ORDER BY total DESC;

-- 6. Integrity check: stored seat count must equal real registrations (expect 0 rows)
SELECT e.id, e.title, e.seats_taken, COUNT(r.id) AS actual
FROM events e LEFT JOIN registrations r ON r.event_id = e.id
GROUP BY e.id HAVING e.seats_taken <> COUNT(r.id);
