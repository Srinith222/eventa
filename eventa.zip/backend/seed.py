"""Insert sample events: python seed.py"""
from datetime import datetime, timedelta
from main import SessionLocal, Event

now = datetime.now().replace(minute=0, second=0, microsecond=0)
SAMPLES = [
    ("Intro to Machine Learning", "Hands-on workshop: build and evaluate your first model in Python.", "Workshop", "Lab 3, CS Block", 7, 30),
    ("Annual Tech Fest Keynote", "Opening keynote with guest speakers from industry.", "Event", "Main Auditorium", 10, 300),
    ("Git & GitHub Bootcamp", "Branching, pull requests and teamwork on real repositories.", "Workshop", "Lab 1, CS Block", 14, 40),
    ("Hackathon Kick-off", "Team formation, problem statements and mentor meet-up.", "Event", "Seminar Hall", 21, 120),
    ("SQL Performance Workshop", "Indexes, query plans and designing schemas that scale.", "Workshop", "Lab 2, CS Block", 28, 25),
    ("Career Fair", "Meet recruiters from 40+ companies. Bring your resume.", "Event", "Sports Complex", 35, 500),
]

with SessionLocal() as db:
    if db.query(Event).count():
        print("Events already exist - nothing seeded.")
    else:
        for title, desc, cat, venue, days, cap in SAMPLES:
            db.add(Event(title=title, description=desc, category=cat, venue=venue,
                         starts_at=now + timedelta(days=days), capacity=cap, seats_taken=0))
        db.commit()
        print(f"Seeded {len(SAMPLES)} events.")
