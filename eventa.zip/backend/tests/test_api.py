import os
os.environ["DATABASE_URL"] = "sqlite:///./test_eventa.db"

import pytest
from fastapi.testclient import TestClient
from main import app, Base, engine


@pytest.fixture()
def client():
    Base.metadata.drop_all(engine)
    Base.metadata.create_all(engine)
    with TestClient(app) as c:
        yield c


def signup(c, n):
    r = c.post("/auth/register", json={"name": f"Student {n}", "email": f"s{n}@x.com", "password": "secret1"})
    assert r.status_code == 201
    return {"Authorization": f"Bearer {r.json()['access_token']}"}


def admin(c):
    r = c.post("/auth/login", data={"username": "admin@eventa.com", "password": "admin123"})
    return {"Authorization": f"Bearer {r.json()['access_token']}"}


def make_event(c, cap=2):
    r = c.post("/events", headers=admin(c), json={"title": "Test", "description": "", "category": "Workshop",
                                                  "venue": "Lab", "starts_at": "2030-01-01T10:00:00", "capacity": cap})
    assert r.status_code == 201
    return r.json()["id"]


def test_capacity_fills_and_blocks(client):
    eid = make_event(client, 2)
    a, b, c3 = signup(client, 1), signup(client, 2), signup(client, 3)
    assert client.post(f"/events/{eid}/register", headers=a).json()["seats_left"] == 1
    assert client.post(f"/events/{eid}/register", headers=b).json()["is_full"] is True
    assert client.post(f"/events/{eid}/register", headers=c3).status_code == 409


def test_no_double_registration(client):
    eid = make_event(client, 5)
    a = signup(client, 1)
    client.post(f"/events/{eid}/register", headers=a)
    assert client.post(f"/events/{eid}/register", headers=a).status_code == 409
    assert client.get(f"/events/{eid}").json()["seats_taken"] == 1


def test_cancel_frees_seat(client):
    eid = make_event(client, 1)
    a, b = signup(client, 1), signup(client, 2)
    client.post(f"/events/{eid}/register", headers=a)
    assert client.delete(f"/events/{eid}/register", headers=a).json()["seats_left"] == 1
    assert client.post(f"/events/{eid}/register", headers=b).status_code == 200


def test_student_cannot_create_event(client):
    r = client.post("/events", headers=signup(client, 1), json={"title": "X", "category": "Event", "venue": "V",
                                                               "starts_at": "2030-01-01T10:00:00", "capacity": 5})
    assert r.status_code == 403


def test_capacity_cannot_drop_below_booked(client):
    eid = make_event(client, 3)
    for i in (1, 2):
        client.post(f"/events/{eid}/register", headers=signup(client, i))
    r = client.put(f"/events/{eid}", headers=admin(client), json={"title": "Test", "description": "", "category": "Workshop",
                                                                "venue": "Lab", "starts_at": "2030-01-01T10:00:00", "capacity": 1})
    assert r.status_code == 400


def test_login_rejects_bad_password(client):
    signup(client, 1)
    assert client.post("/auth/login", data={"username": "s1@x.com", "password": "wrong"}).status_code == 401
