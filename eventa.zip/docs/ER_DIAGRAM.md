# Eventa - Database Design

```mermaid
erDiagram
    USERS ||--o{ REGISTRATIONS : makes
    EVENTS ||--o{ REGISTRATIONS : receives
    USERS {
        int id PK
        string name
        string email UK
        string password_hash
        enum role "student | admin"
        datetime created_at
    }
    EVENTS {
        int id PK
        string title
        text description
        enum category "Event | Workshop"
        string venue
        datetime starts_at
        int capacity
        int seats_taken
        datetime created_at
    }
    REGISTRATIONS {
        int id PK
        int user_id FK
        int event_id FK
        datetime created_at
    }
```

## Design notes
- **Users - Events** is many-to-many, resolved by `registrations`, with `UNIQUE(user_id, event_id)` so nobody registers twice.
- **Capacity** is enforced three ways: the API checks `seats_taken < capacity` under a row lock
  (`SELECT ... FOR UPDATE`), the MySQL `CHECK (seats_taken <= capacity)` rejects bad data, and
  `queries.sql` has an integrity query that compares `seats_taken` with the real registration count.
- Deleting a user or event cascades to its registrations (`ON DELETE CASCADE`).
- The schema is in 3NF: `seats_taken` is a deliberate, transaction-protected counter that avoids a COUNT on every page load.

## API summary
| Method | Path | Access |
|---|---|---|
| POST | /auth/register, /auth/login | public |
| GET | /auth/me | signed in |
| GET | /events, /events/{id} | public |
| POST | /events/{id}/register | student |
| DELETE | /events/{id}/register | student |
| GET | /me/registrations | student |
| POST/PUT/DELETE | /events, /events/{id} | admin |
| GET | /events/{id}/attendees | admin |
