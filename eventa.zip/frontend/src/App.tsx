import { Routes, Route, Navigate } from "react-router-dom";
import Sidebar from "./Sidebar";
import Home from "./pages/Home";
import Events from "./pages/Events";
import MyRegistrations from "./pages/MyRegistrations";
import Admin from "./pages/Admin";
import Login from "./pages/Login";
import NotFound from "./pages/NotFound";
import { useAuth } from "./auth";

export default function App() {
  const { user, loading } = useAuth();
  if (loading) return <div className="min-h-screen grid place-items-center text-muted-foreground">Loading…</div>;
  return (
    <div className="min-h-screen">
      <Sidebar />
      <main className="md:ml-64 min-h-screen">
        <Routes>
          <Route path="/" element={<Home />} />
          <Route path="/events" element={<Events />} />
          <Route path="/login" element={user ? <Navigate to="/events" /> : <Login />} />
          <Route path="/my-registrations" element={user ? <MyRegistrations /> : <Navigate to="/login" />} />
          <Route path="/admin" element={user?.role === "admin" ? <Admin /> : <Navigate to="/login" />} />
          <Route path="*" element={<NotFound />} />
        </Routes>
      </main>
    </div>
  );
}
