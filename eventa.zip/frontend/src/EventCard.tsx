import { useState } from "react";
import { MapPin, Clock, Users } from "lucide-react";
import { api, EventItem } from "./api";
import { useAuth } from "./auth";
import { useNavigate } from "react-router-dom";

export const fmt = (s: string) =>
  new Date(s).toLocaleString(undefined, { dateStyle: "medium", timeStyle: "short" });

export default function EventCard({ ev, onChange }: { ev: EventItem; onChange: (e: EventItem) => void }) {
  const { user } = useAuth();
  const nav = useNavigate();
  const [busy, setBusy] = useState(false);
  const [err, setErr] = useState("");
  const pct = Math.min(100, Math.round((ev.seats_taken / ev.capacity) * 100));

  const act = async () => {
    if (!user) return nav("/login");
    setBusy(true); setErr("");
    try {
      onChange(await api<EventItem>(`/events/${ev.id}/register`, { method: ev.is_registered ? "DELETE" : "POST" }));
    } catch (e: any) {
      setErr(e.message);
      api<EventItem>(`/events/${ev.id}`).then(onChange).catch(() => {}); // refresh seat count after a conflict
    } finally { setBusy(false); }
  };

  return (
    <article className="rounded-2xl bg-card border border-border p-5 flex flex-col gap-4">
      <div className="flex items-center justify-between">
        <span className="liquid-glass rounded-md px-2 py-0.5 text-xs font-medium">{ev.category}</span>
        {ev.is_full && !ev.is_registered && <span className="text-xs text-muted-foreground">Full</span>}
      </div>
      <div>
        <h3 className="text-xl font-medium tracking-tight">{ev.title}</h3>
        <p className="text-sm text-muted-foreground mt-1 line-clamp-3">{ev.description}</p>
      </div>
      <div className="text-sm text-muted-foreground space-y-1">
        <p className="flex items-center gap-2"><Clock size={14} />{fmt(ev.starts_at)}</p>
        <p className="flex items-center gap-2"><MapPin size={14} />{ev.venue}</p>
        <p className="flex items-center gap-2"><Users size={14} />{ev.seats_taken} of {ev.capacity} seats taken</p>
      </div>
      <div>
        <div className="h-1.5 rounded-full bg-white/10 overflow-hidden">
          <div className="h-full bg-foreground transition-all duration-500" style={{ width: `${pct}%` }} />
        </div>
        <p className="text-xs text-muted-foreground mt-1.5">{ev.is_full ? "No seats left" : `${ev.seats_left} seats left`}</p>
      </div>
      {err && <p role="alert" className="text-sm text-red-400">{err}</p>}
      <button onClick={act} disabled={busy || (ev.is_full && !ev.is_registered)}
        className={ev.is_registered ? "btn-ghost" : "btn"}>
        {busy ? "Please wait…" : ev.is_registered ? "Cancel registration" : ev.is_full ? "Event full" : "Register"}
      </button>
    </article>
  );
}
