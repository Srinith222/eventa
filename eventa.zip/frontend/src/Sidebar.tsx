import { useState } from "react";
import { NavLink, Link, useNavigate } from "react-router-dom";
import { Home, CalendarDays, Ticket, ShieldCheck, LogIn, LogOut, Menu, X } from "lucide-react";
import { useAuth } from "./auth";

export default function Sidebar() {
  const { user, logout } = useAuth();
  const [open, setOpen] = useState(false);
  const nav = useNavigate();
  const links = [
    { to: "/", label: "Home", icon: Home },
    { to: "/events", label: "Events & workshops", icon: CalendarDays },
    ...(user ? [{ to: "/my-registrations", label: "My registrations", icon: Ticket }] : []),
    ...(user?.role === "admin" ? [{ to: "/admin", label: "Manage events", icon: ShieldCheck }] : []),
  ];
  const item = ({ isActive }: { isActive: boolean }) =>
    `flex items-center gap-3 rounded-lg px-3 py-2.5 text-sm font-medium transition-colors ${
      isActive ? "bg-white/10 text-foreground" : "text-muted-foreground hover:bg-white/5 hover:text-foreground"}`;

  return (
    <>
      <button aria-label="Open menu" onClick={() => setOpen(true)}
        className="md:hidden fixed top-4 left-4 z-40 liquid-glass rounded-lg p-2"><Menu size={20} /></button>
      {open && <div className="md:hidden fixed inset-0 z-40 bg-black/60" onClick={() => setOpen(false)} />}
      <aside className={`fixed inset-y-0 left-0 z-50 w-64 bg-background border-r border-border flex flex-col px-4 py-5 transition-transform
        ${open ? "translate-x-0" : "-translate-x-full"} md:translate-x-0`}>
        <div className="flex items-center justify-between mb-10 px-1">
          <Link to="/" className="flex items-center gap-2 text-xl font-bold tracking-tight" onClick={() => setOpen(false)}>
            <span className="grid place-items-center w-7 h-7 rounded-md bg-foreground text-background text-sm font-bold">E</span>Eventa
          </Link>
          <button className="md:hidden" aria-label="Close menu" onClick={() => setOpen(false)}><X size={20} /></button>
        </div>
        <nav className="flex flex-col gap-1 flex-1">
          {links.map(({ to, label, icon: Icon }) => (
            <NavLink key={to} to={to} end={to === "/"} className={item} onClick={() => setOpen(false)}>
              <Icon size={18} />{label}
            </NavLink>
          ))}
        </nav>
        <div className="border-t border-border pt-4">
          {user ? (
            <>
              <div className="px-1 mb-3"><p className="text-sm font-semibold truncate">{user.name}</p>
                <p className="text-xs text-muted-foreground truncate">{user.email}</p></div>
              <button className="btn-ghost w-full flex items-center justify-center gap-2"
                onClick={() => { logout(); setOpen(false); nav("/"); }}><LogOut size={16} />Sign out</button>
            </>
          ) : (
            <Link to="/login" onClick={() => setOpen(false)} className="btn w-full flex items-center justify-center gap-2">
              <LogIn size={16} />Sign in</Link>
          )}
        </div>
      </aside>
    </>
  );
}
