export const API = import.meta.env.VITE_API_URL || "http://localhost:8000";

export interface User { id: number; name: string; email: string; role: "student" | "admin"; }
export interface EventItem {
  id: number; title: string; description: string; category: "Event" | "Workshop"; venue: string;
  starts_at: string; capacity: number; seats_taken: number; seats_left: number;
  is_full: boolean; is_registered: boolean;
}
export type EventInput = Pick<EventItem, "title" | "description" | "category" | "venue" | "starts_at" | "capacity">;

export async function api<T>(path: string, opts: RequestInit & { form?: Record<string, string> } = {}): Promise<T> {
  const headers: Record<string, string> = {};
  const token = localStorage.getItem("token");
  if (token) headers.Authorization = `Bearer ${token}`;
  let body = opts.body;
  if (opts.form) {
    headers["Content-Type"] = "application/x-www-form-urlencoded";
    body = new URLSearchParams(opts.form).toString();
  } else if (body) headers["Content-Type"] = "application/json";
  const res = await fetch(API + path, { ...opts, headers, body });
  if (res.status === 204) return undefined as T;
  const data = await res.json().catch(() => ({}));
  if (!res.ok) {
    const d = data.detail;
    throw new Error(Array.isArray(d) ? d.map((x: any) => x.msg).join(", ") : d || "Something went wrong");
  }
  return data as T;
}
