import { createContext, useContext, useEffect, useState, ReactNode } from "react";
import { api, User } from "./api";

interface Ctx {
  user: User | null; loading: boolean;
  login: (email: string, password: string) => Promise<void>;
  signup: (name: string, email: string, password: string) => Promise<void>;
  logout: () => void;
}
const AuthCtx = createContext<Ctx>(null!);
export const useAuth = () => useContext(AuthCtx);

export function AuthProvider({ children }: { children: ReactNode }) {
  const [user, setUser] = useState<User | null>(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    if (!localStorage.getItem("token")) return setLoading(false);
    api<User>("/auth/me").then(setUser).catch(() => localStorage.removeItem("token")).finally(() => setLoading(false));
  }, []);

  const finish = (r: { access_token: string; user: User }) => { localStorage.setItem("token", r.access_token); setUser(r.user); };
  const login = async (email: string, password: string) =>
    finish(await api("/auth/login", { method: "POST", form: { username: email, password } }));
  const signup = async (name: string, email: string, password: string) =>
    finish(await api("/auth/register", { method: "POST", body: JSON.stringify({ name, email, password }) }));
  const logout = () => { localStorage.removeItem("token"); setUser(null); };

  return <AuthCtx.Provider value={{ user, loading, login, signup, logout }}>{children}</AuthCtx.Provider>;
}
