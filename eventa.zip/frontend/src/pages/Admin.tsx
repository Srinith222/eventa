import { useEffect, useState, FormEvent } from "react";
import { api, EventItem, User } from "../api";
import { fmt } from "../EventCard";

type Attendee = User & { registered_at: string };
const blank = { title: "", description: "", category: "Event" as "Event" | "Workshop", venue: "", starts_at: "", capacity: 50 };

export default function Admin() {
  const [events, setEvents] = useState<EventItem[]>([]);
  const [form, setForm] = useState(blank);
  const [editId, setEditId] = useState<number | null>(null);
  const [err, setErr] = useState("");
  const [att, setAtt] = useState<{ id: number; list: Attendee[] } | null>(null);

  const load = () => api<EventItem[]>("/events").then(setEvents);
  useEffect(() => { load(); }, []);

  const submit = async (e: FormEvent) => {
    e.preventDefault(); setErr("");
    try {
      await api(editId ? `/events/${editId}` : "/events", { method: editId ? "PUT" : "POST", body: JSON.stringify({ ...form, capacity: Number(form.capacity) }) });
      setForm(blank); setEditId(null); load();
    } catch (x: any) { setErr(x.message); }
  };
  const edit = (ev: EventItem) => { setEditId(ev.id); setForm({ ...ev, starts_at: ev.starts_at.slice(0, 16) }); window.scrollTo({ top: 0, behavior: "smooth" }); };
  const del = async (id: number) => { if (confirm("Delete this event and all its registrations?")) { await api(`/events/${id}`, { method: "DELETE" }); load(); } };
  const showAtt = async (id: number) => setAtt({ id, list: await api<Attendee[]>(`/events/${id}/attendees`) });

  return (
    <div className="px-6 md:px-12 py-20 md:py-12 max-w-5xl">
      <h1 className="text-4xl md:text-5xl font-medium tracking-[-1.5px] mb-8">Manage events</h1>
      <form onSubmit={submit} className="rounded-2xl bg-card border border-border p-6 grid gap-3 sm:grid-cols-2 mb-10">
        <input className="field sm:col-span-2" placeholder="Title" required value={form.title} onChange={(e) => setForm({ ...form, title: e.target.value })} />
        <textarea className="field sm:col-span-2" rows={3} placeholder="Description" value={form.description} onChange={(e) => setForm({ ...form, description: e.target.value })} />
        <select className="field" value={form.category} onChange={(e) => setForm({ ...form, category: e.target.value as any })}>
          <option>Event</option><option>Workshop</option></select>
        <input className="field" placeholder="Venue" required value={form.venue} onChange={(e) => setForm({ ...form, venue: e.target.value })} />
        <input className="field" type="datetime-local" required value={form.starts_at} onChange={(e) => setForm({ ...form, starts_at: e.target.value })} />
        <input className="field" type="number" min={1} required placeholder="Capacity" value={form.capacity} onChange={(e) => setForm({ ...form, capacity: Number(e.target.value) })} />
        {err && <p role="alert" className="text-sm text-red-400 sm:col-span-2">{err}</p>}
        <div className="flex gap-3 sm:col-span-2">
          <button className="btn">{editId ? "Save changes" : "Create event"}</button>
          {editId && <button type="button" className="btn-ghost" onClick={() => { setEditId(null); setForm(blank); }}>Cancel edit</button>}
        </div>
      </form>

      <div className="flex flex-col gap-3">
        {events.length === 0 && <p className="text-muted-foreground">No events yet. Create your first one above.</p>}
        {events.map((ev) => (
          <div key={ev.id} className="rounded-xl bg-card border border-border p-4">
            <div className="flex flex-wrap items-center justify-between gap-3">
              <div><p className="font-medium">{ev.title} <span className="text-xs text-muted-foreground ml-2">{ev.category}</span></p>
                <p className="text-sm text-muted-foreground">{fmt(ev.starts_at)} · {ev.venue} · {ev.seats_taken}/{ev.capacity} seats</p></div>
              <div className="flex gap-2">
                <button className="btn-ghost" onClick={() => showAtt(ev.id)}>Attendees</button>
                <button className="btn-ghost" onClick={() => edit(ev)}>Edit</button>
                <button className="btn-ghost text-red-400" onClick={() => del(ev.id)}>Delete</button>
              </div>
            </div>
            {att?.id === ev.id && (
              <ul className="mt-3 pt-3 border-t border-border text-sm space-y-1">
                {att.list.length === 0 ? <li className="text-muted-foreground">No registrations yet.</li> :
                  att.list.map((a) => <li key={a.id}>{a.name} <span className="text-muted-foreground">({a.email})</span></li>)}
              </ul>
            )}
          </div>
        ))}
      </div>
    </div>
  );
}
