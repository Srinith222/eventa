import { useEffect, useState } from "react";
import { api, EventItem } from "../api";
import EventCard from "../EventCard";
import { useAuth } from "../auth";

export default function Events() {
  const { user } = useAuth();
  const [events, setEvents] = useState<EventItem[]>([]);
  const [filter, setFilter] = useState<"All" | "Event" | "Workshop">("All");
  const [q, setQ] = useState("");
  const [state, setState] = useState<"loading" | "ok" | "error">("loading");

  useEffect(() => {
    setState("loading");
    api<EventItem[]>("/events").then((d) => { setEvents(d); setState("ok"); }).catch(() => setState("error"));
  }, [user?.id]);

  const shown = events.filter((e) => (filter === "All" || e.category === filter) &&
    (e.title + e.venue).toLowerCase().includes(q.toLowerCase()));
  const update = (u: EventItem) => setEvents((list) => list.map((e) => (e.id === u.id ? { ...e, ...u, is_registered: u.is_registered } : e)));

  return (
    <div className="px-6 md:px-12 py-20 md:py-12 max-w-6xl">
      <h1 className="text-4xl md:text-5xl font-medium tracking-[-1.5px] mb-2">Events & workshops</h1>
      <p className="text-muted-foreground mb-8">Pick a session and reserve your seat. Seat counts update the moment someone registers.</p>
      <div className="flex flex-wrap gap-3 mb-8">
        <input className="field max-w-xs" placeholder="Search by title or venue" value={q} onChange={(e) => setQ(e.target.value)} />
        {(["All", "Event", "Workshop"] as const).map((f) => (
          <button key={f} onClick={() => setFilter(f)} className={filter === f ? "btn" : "btn-ghost"}>{f}</button>
        ))}
      </div>
      {state === "loading" && <p className="text-muted-foreground">Loading events…</p>}
      {state === "error" && <p className="text-red-400">Can't reach the server. Check that the API is running on port 8000.</p>}
      {state === "ok" && shown.length === 0 && <p className="text-muted-foreground">No events match. Try clearing the search or filter.</p>}
      <div className="grid gap-5 sm:grid-cols-2 lg:grid-cols-3">
        {shown.map((e) => <EventCard key={e.id} ev={e} onChange={update} />)}
      </div>
    </div>
  );
}
