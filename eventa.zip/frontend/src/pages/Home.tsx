import { useEffect, useRef, useState } from "react";
import { Link } from "react-router-dom";
import { motion, useScroll, useTransform, MotionValue } from "framer-motion";
import { api, EventItem } from "../api";
import { fmt } from "../EventCard";

const VIDEO = "https://d8j0ntlcm91z4.cloudfront.net/user_38xzZboKViGWJOttwIXH07lWA1P/hf_20260307_083826_e938b29f-a43a-41ec-a153-3d4730578ab8.mp4";
const QUOTE = "Eventa changed how our campus runs workshops. Students see real seat counts, sign up in seconds, and we stop worrying about overbooked rooms. We now fill every session faster than we ever imagined!";

function Word({ w, i, total, p }: { w: string; i: number; total: number; p: MotionValue<number> }) {
  const r: [number, number] = [i / total, (i + 1) / total];
  const opacity = useTransform(p, r, [0.2, 1]);
  const color = useTransform(p, r, ["hsl(0 0% 35%)", "hsl(0 0% 100%)"]);
  return <motion.span style={{ opacity, color }} className="mr-[0.3em]">{w}</motion.span>;
}

export default function Home() {
  const sectionRef = useRef<HTMLElement>(null);
  const quoteRef = useRef<HTMLDivElement>(null);
  const [events, setEvents] = useState<EventItem[]>([]);
  useEffect(() => { api<EventItem[]>("/events").then((d) => setEvents(d.slice(0, 3))).catch(() => {}); }, []);

  const { scrollYProgress } = useScroll({ target: sectionRef, offset: ["start start", "end start"] });
  const textY = useTransform(scrollYProgress, [0, 1], [0, -200]);
  const textOpacity = useTransform(scrollYProgress, [0, 0.5], [1, 0]);
  const panelY = useTransform(scrollYProgress, [0, 1], [0, -250]);
  const { scrollYProgress: qp } = useScroll({ target: quoteRef, offset: ["start end", "end center"] });
  const words = QUOTE.split(" ");

  return (
    <>
      <section ref={sectionRef} className="relative min-h-screen overflow-hidden">
        <motion.div style={{ y: textY, opacity: textOpacity }} className="flex flex-col items-center text-center mt-24 md:mt-20 px-4">
          <motion.div initial={{ opacity: 0, y: 10 }} animate={{ opacity: 1, y: 0 }} transition={{ duration: 0.5 }}
            className="liquid-glass inline-flex items-center gap-2 px-3 py-2 rounded-lg mb-6">
            <span className="bg-foreground text-background rounded-md text-sm font-medium px-2 py-0.5">New</span>
            <span className="text-sm font-medium text-muted-foreground">Live seat counts on every event</span>
          </motion.div>
          <motion.h1 initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ duration: 0.6, delay: 0.1 }}
            className="text-5xl md:text-7xl tracking-[-2px] font-medium leading-tight md:leading-[1.15] mb-3">
            Find Your Event.<br />Save Your <span className="font-serif italic font-normal">Seat</span>.
          </motion.h1>
          <motion.p initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ duration: 0.6, delay: 0.2 }}
            className="text-lg font-normal leading-6 opacity-90 mb-8" style={{ color: "hsl(var(--hero-subtitle))" }}>
            Eventa lets students browse events and workshops,<br />register in one click, and see seats left in real time.
          </motion.p>
          <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ duration: 0.6, delay: 0.3 }}>
            <motion.div whileHover={{ scale: 1.03 }} whileTap={{ scale: 0.98 }} className="inline-block">
              <Link to="/events" className="inline-block bg-foreground text-background rounded-full px-8 py-3.5 text-base font-medium">Browse events</Link>
            </motion.div>
          </motion.div>
        </motion.div>

        <motion.div initial={{ opacity: 0, y: 40 }} animate={{ opacity: 1, y: 0 }} transition={{ duration: 0.8, delay: 0.4 }}
          className="relative w-full mt-10" style={{ aspectRatio: "16/9", minHeight: 420 }}>
          <video className="absolute inset-0 w-full h-full object-cover" src={VIDEO} autoPlay loop muted playsInline />
          <motion.div style={{ y: panelY }} className="absolute inset-0 grid place-items-center">
            <div className="max-w-5xl w-[90%] rounded-2xl liquid-glass p-5 grid gap-3 md:grid-cols-3 bg-black/40">
              {events.length === 0 && <p className="text-sm text-muted-foreground md:col-span-3">Upcoming events will appear here.</p>}
              {events.map((e) => (
                <Link to="/events" key={e.id} className="rounded-xl bg-card/80 border border-border p-4 block">
                  <p className="font-medium">{e.title}</p>
                  <p className="text-xs text-muted-foreground mt-1">{fmt(e.starts_at)}</p>
                  <p className="text-sm mt-3">{e.is_full ? "Full" : `${e.seats_left} of ${e.capacity} seats left`}</p>
                </Link>
              ))}
            </div>
          </motion.div>
        </motion.div>
        <div className="absolute bottom-0 inset-x-0 h-40 z-30 pointer-events-none bg-gradient-to-t from-background to-transparent" />
      </section>

      <section className="min-h-screen flex items-center py-24 md:py-32 px-8 md:px-28">
        <div ref={quoteRef} className="max-w-3xl mx-auto flex flex-col items-start gap-10">
          <span className="font-serif text-7xl leading-none h-10 text-muted-foreground">“</span>
          <p className="text-4xl md:text-5xl font-medium leading-[1.2] flex flex-wrap">
            {words.map((w, i) => <Word key={i} w={w} i={i} total={words.length} p={qp} />)}
            <span className="text-muted-foreground ml-2">”</span>
          </p>
          <div className="flex items-center gap-4">
            <div className="w-14 h-14 rounded-full border-[3px] border-foreground bg-card grid place-items-center font-semibold">BS</div>
            <div><p className="text-base font-semibold leading-7">Brooklyn Simmons</p>
              <p className="text-sm font-normal leading-5 text-muted-foreground">Workshop Coordinator</p></div>
          </div>
        </div>
      </section>
    </>
  );
}
