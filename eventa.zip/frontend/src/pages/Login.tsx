import { useState, FormEvent } from "react";
import { useAuth } from "../auth";

export default function Login() {
  const { login, signup } = useAuth();
  const [mode, setMode] = useState<"login" | "signup">("login");
  const [f, setF] = useState({ name: "", email: "", password: "" });
  const [err, setErr] = useState("");
  const [busy, setBusy] = useState(false);

  const submit = async (e: FormEvent) => {
    e.preventDefault(); setBusy(true); setErr("");
    try { mode === "login" ? await login(f.email, f.password) : await signup(f.name, f.email, f.password); }
    catch (x: any) { setErr(x.message); } finally { setBusy(false); }
  };

  return (
    <div className="min-h-screen grid place-items-center px-6">
      <form onSubmit={submit} className="w-full max-w-sm rounded-2xl bg-card border border-border p-7 flex flex-col gap-4">
        <h1 className="text-3xl font-medium tracking-tight">{mode === "login" ? "Sign in" : "Create your account"}</h1>
        {mode === "signup" && <input className="field" placeholder="Full name" required value={f.name} onChange={(e) => setF({ ...f, name: e.target.value })} />}
        <input className="field" type="email" placeholder="Email" required value={f.email} onChange={(e) => setF({ ...f, email: e.target.value })} />
        <input className="field" type="password" placeholder="Password (6+ characters)" required minLength={6} value={f.password} onChange={(e) => setF({ ...f, password: e.target.value })} />
        {err && <p role="alert" className="text-sm text-red-400">{err}</p>}
        <button className="btn" disabled={busy}>{busy ? "Please wait…" : mode === "login" ? "Sign in" : "Create account"}</button>
        <button type="button" className="text-sm text-muted-foreground hover:text-foreground"
          onClick={() => { setMode(mode === "login" ? "signup" : "login"); setErr(""); }}>
          {mode === "login" ? "New here? Create an account" : "Already registered? Sign in"}
        </button>
      </form>
    </div>
  );
}
