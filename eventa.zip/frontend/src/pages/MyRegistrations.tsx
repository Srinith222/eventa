import { useEffect, useState } from "react";
import { Link } from "react-router-dom";
import { api, EventItem } from "../api";
import EventCard from "../EventCard";

export default function MyRegistrations() {
  const [events, setEvents] = useState<EventItem[]>([]);
  const [loaded, setLoaded] = useState(false);
  useEffect(() => { api<EventItem[]>("/me/registrations").then(setEvents).finally(() => setLoaded(true)); }, []);

  return (
    <div className="px-6 md:px-12 py-20 md:py-12 max-w-6xl">
      <h1 className="text-4xl md:text-5xl font-medium tracking-[-1.5px] mb-8">My registrations</h1>
      {loaded && events.length === 0 && (
        <p className="text-muted-foreground">You haven't registered for anything yet. <Link to="/events" className="underline text-foreground">Browse events</Link></p>
      )}
      <div className="grid gap-5 sm:grid-cols-2 lg:grid-cols-3">
        {events.map((e) => (
          <EventCard key={e.id} ev={e} onChange={(u) => u.is_registered ? setEvents((l) => l.map((x) => x.id === u.id ? u : x)) : setEvents((l) => l.filter((x) => x.id !== u.id))} />
        ))}
      </div>
    </div>
  );
}
