import { Link } from "react-router-dom";
export default function NotFound() {
  return (
    <div className="min-h-screen grid place-items-center px-6 text-center">
      <div>
        <h1 className="text-6xl font-medium tracking-[-2px] mb-3">404</h1>
        <p className="text-muted-foreground mb-6">That page doesn't exist.</p>
        <Link to="/events" className="btn">Browse events</Link>
      </div>
    </div>
  );
}
